//
//  CustomTabBarController.swift
//  TodoList
//
//  Created by 정지훈 on 2022/11/10.
//

import UIKit

class CustomTabBarController: UITabBarController {

    override func viewDidLoad() {
        super.viewDidLoad()
        self.tabBar.
    }

}
